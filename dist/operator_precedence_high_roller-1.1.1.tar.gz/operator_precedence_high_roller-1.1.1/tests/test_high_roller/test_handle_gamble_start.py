from src.operator_precedence_high_roller.high_roller import HighRoller

hr = HighRoller()

#work in progress :)