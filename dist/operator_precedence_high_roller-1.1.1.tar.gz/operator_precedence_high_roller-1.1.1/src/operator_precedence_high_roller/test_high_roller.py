import unittest
import high_roller

high_roller.stop_testing_messages()
high_roller.client.close()